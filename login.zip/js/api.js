import { config } from './config.js';

/**
 * Tu función original para llamar a la API (se mantiene sin cambios).
 */
async function fetchApiData(queryGuid, params) {
    try {
        const response = await fetch(config.apiUrl, {
            method: 'POST',
            headers: { 'Api-Token': config.apiToken, 'Accept': 'application/json', 'Content-Type': 'application/json; charset=utf-8' },
            body: JSON.stringify({ "QueryGuid": queryGuid, "Params": params })
        });
        if (!response.ok) {
            console.error(`Error ${response.status} en la consulta API para ${queryGuid}.`);
            return [];
        }
        return await response.json();
    } catch (error) {
        console.error("Error de red o de fetch:", error);
        return [];
    }
}

/**
 * Nueva función que gestiona la caché de forma inteligente.
 */
async function fetchAndCache(reportGuid, requestedDates) {
    if (!requestedDates) return null;

    const requestedFrom = new Date(requestedDates.from);
    
    // --- CORRECCIÓN 1: Ajustamos la fecha de fin al final del día ---
    const requestedTo = new Date(requestedDates.to);
    requestedTo.setHours(23, 59, 59, 999); // Clave para incluir todo el día de fin

    const allKeys = await localforage.keys();
    const reportKeys = allKeys.filter(key => key.startsWith(`cache_${reportGuid}_`));

    for (const key of reportKeys) {
        const [,, cachedFromStr, cachedToStr] = key.split('_');
        const cachedFrom = new Date(cachedFromStr);
        const cachedTo = new Date(cachedToStr);
        cachedTo.setHours(23, 59, 59, 999); // Hacemos lo mismo para la fecha cacheada

        if (requestedFrom >= cachedFrom && requestedTo <= cachedTo) {
            console.log(`✅ Cache HIT Inteligente! Usando datos de ${key} para la petición de ${requestedDates.from} a ${requestedDates.to}`);
            
            const supersetData = await localforage.getItem(key);

            const filteredData = supersetData.filter(item => {
                // --- CORRECCIÓN 2: Lógica de parseo de fechas más robusta ---
                const dateField = item.BusinessDay || item.Fecha || item.CreationDate;
                if (!dateField) return false;

                let itemDate;
                // Si la fecha viene en formato 'DD/MM/YYYY', la convertimos correctamente
                if (String(dateField).includes('/')) {
                    const [day, month, year] = dateField.split('/');
                    itemDate = new Date(`${year}-${month}-${day}T00:00:00`);
                } else { // Si no, asumimos que es un formato estándar como ISO 'YYYY-MM-DDTHH:mm:ss'
                    itemDate = new Date(dateField);
                }
                
                // Ignoramos fechas inválidas y hacemos la comparación
                return !isNaN(itemDate.getTime()) && itemDate >= requestedFrom && itemDate <= requestedTo;
            });
            
            console.log(`Filtrado completo. Se encontraron ${filteredData.length} registros en el rango.`);
            return filteredData;
        }
    }

    const cacheKey = `cache_${reportGuid}_${requestedDates.from}_${requestedDates.to}`;
    console.log(`⚫️ Cache MISS for ${cacheKey}. Fetching from API...`);
    const apiData = await fetchApiData(reportGuid, requestedDates);

    if (apiData && apiData.length > 0) {
        try {
            await localforage.setItem(cacheKey, apiData);
            console.log(`📦 Saved ${cacheKey} to cache.`);
        } catch (error) {
            console.error("Error al guardar en localForage:", error);
        }
    }

    return apiData;
}


export async function fetchDualPeriodData(guid, mainDates, comparisonDates) {
    const mainPromise = fetchAndCache(guid, mainDates);
    const comparisonPromise = comparisonDates ? fetchAndCache(guid, comparisonDates) : Promise.resolve(null);
    
    return await Promise.all([mainPromise, comparisonPromise]);
}