export function hexToRgba(hex, alpha = 1) {
    if (!hex || !hex.startsWith('#')) return `rgba(128, 222, 234, ${alpha})`;
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function getComparisonHtml(current, previous) {
    const comparisonSelector = document.getElementById('comparisonSelector');
    if (previous === null || previous === undefined || comparisonSelector.value === 'none') return '';
    if (previous === 0) {
        return current > 0 ? `<span class="comparison increase">▲ Nuevo</span>` : '';
    }
    if (current === previous) return `<span class="comparison">→ 0%</span>`;
    
    const diff = ((current - previous) / previous) * 100;
    const cssClass = diff >= 0 ? 'increase' : 'decrease';
    const arrow = diff >= 0 ? '▲' : '▼';
    return `<span class="comparison ${cssClass}">${arrow} ${diff.toFixed(1)}%</span>`;
}

export function getComparisonDates(startDateStr, endDateStr, type) {
    if (type === 'none') return null;
    const from = new Date(startDateStr + 'T00:00:00');
    const to = new Date(endDateStr + 'T23:59:59');
    let compFrom = new Date(from);
    let compTo = new Date(to);

    if (type === 'previous') {
        const diff = to.getTime() - from.getTime();
        compFrom.setTime(from.getTime() - diff - (24 * 60 * 60 * 1000));
        compTo.setTime(from.getTime() - 1);
    } else if (type === 'last_year') {
        compFrom.setFullYear(compFrom.getFullYear() - 1);
        compTo.setFullYear(compTo.getFullYear() - 1);
    }
    return { from: compFrom.toISOString().split('T')[0], to: compTo.toISOString().split('T')[0] };
}

// --- FUNCIÓN DEFINITIVA Y CORREGIDA PARA LEER LAS MERMAS ---
export function parseMermaDetails(details) {
    if (!details) {
        return { motivo: 'Sin Motivo', productos: [] };
    }

    // Expresión regular que acepta espacios en blanco y saltos de línea (`\s*`)
    const motivoMatch = details.match(/Motivo:\s*(.*?)(?=\s*Líneas:|$)/s);
    const motivo = motivoMatch ? motivoMatch[1].trim() : 'Sin Motivo';

    // Expresión regular que también acepta saltos de línea después de "Líneas:"
    const lineasMatch = details.match(/Líneas:\s*(.*)/s);
    if (!lineasMatch || !lineasMatch[1]) {
        return { motivo, productos: [] };
    }

    const lineasStr = lineasMatch[1];
    const productosAgrupados = {};

    // Bucle robusto para encontrar todos los pares producto-cantidad
    const regex = /(.+?) Cantidad: ([\d,.]+)/g;
    let match;

    while ((match = regex.exec(lineasStr)) !== null) {
        const nombre = match[1].trim();
        const cantidad = parseFloat(match[2].replace(',', '.'));

        if (nombre && !isNaN(cantidad)) {
            productosAgrupados[nombre] = (productosAgrupados[nombre] || 0) + cantidad;
        }
    }
    
    const productosFinal = Object.keys(productosAgrupados).map(nombre => ({
        nombre: nombre,
        cantidad: productosAgrupados[nombre]
    }));

    return { motivo, productos: productosFinal };
}