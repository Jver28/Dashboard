import { hexToRgba } from './utils.js';
import { analysisChartPalettes, paymentMethodConfig } from './config.js';
import { applyResumenChartFilter } from './page_resumen.js';
import { applyMermaFilter } from './page_operaciones.js';

export const charts = {
    // Gráficos de Resumen
    ventasHora: null,
    ventasMetodoPago: null,
    paymentMethodByHourChart: null,
    
    // Gráficos de Ventas
    ventasFamilia: null,
    ventasCategoria: null,
    ventasUsuario: null,

    // Gráficos de Operaciones
    cancelacionesUsuario: null,
    mermasUsuarioChart: null,
    mermasMotivo: null,

    // --> AÑADIDO: Nuevos gráficos para la página de Servicios
    ventasPorZonaChart: null,
    gastoComensalZonaChart: null
};

export function createAllCharts(state) {
    const commonOptions = {
        maintainAspectRatio: false, responsive: true,
        plugins: {
            legend: { display: true, position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } },
            tooltip: { enabled: true, mode: 'index', intersect: false,
                backgroundColor: 'var(--surface-color)', titleColor: 'var(--text-primary)',
                bodyColor: 'var(--text-secondary)', borderColor: 'var(--border-color)',
                borderWidth: 1, padding: 10,
            }
        },
        scales: {
            y: { ticks: { color: 'var(--text-secondary)', beginAtZero: true }, grid: { color: 'var(--border-color)' } },
            x: { ticks: { color: 'var(--text-secondary)' }, grid: { display: false } }
        }
    };
    
    // Gráficos de Resumen
    const ventasHoraCanvas = document.getElementById('ventasHoraChart');
    if (ventasHoraCanvas) {
        charts.ventasHora = new Chart(ventasHoraCanvas, { 
            type: 'line', 
            data: { datasets: [{ label: 'Total', tension: 0.4, fill: true }, { label: 'Filtro', tension: 0.4, fill: true }] },
            options: { ...commonOptions, plugins: {...commonOptions.plugins, legend: { display: false }} } 
        });
    }
    
    const ventasMetodoPagoCanvas = document.getElementById('ventasMetodoPagoChart');
    if (ventasMetodoPagoCanvas) {
        charts.ventasMetodoPago = new Chart(ventasMetodoPagoCanvas, { 
            type: 'doughnut', 
            data: { datasets: [{ borderWidth: 0 }] }, 
            options: { ...commonOptions, scales: {},
                plugins: { ...commonOptions.plugins, tooltip: { callbacks: { label: (context) => `${context.label}: ${new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(context.raw)}` } } },
                onClick: (evt, elements) => {
                    if (elements.length > 0) {
                        const i = elements[0].index;
                        const label = charts.ventasMetodoPago.data.labels[i];
                        const color = charts.ventasMetodoPago.data.datasets[0].backgroundColor[i];
                        applyResumenChartFilter(state, label, color);
                    }
                }
            } 
        });
    }
    
    const paymentMethodByHourCanvas = document.getElementById('paymentMethodByHourChart');
    if (paymentMethodByHourCanvas) {
        charts.paymentMethodByHourChart = new Chart(paymentMethodByHourCanvas, { type: 'line', data: { datasets: []}, options: { ...commonOptions, plugins: { ...commonOptions.plugins, tooltip: { callbacks: { label: (context) => `${context.dataset.label}: ${new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(context.raw)}` } } } } });
    }
    
    // Gráficos de Análisis de Ventas
    const barChartOptions = (unit) => ({ ...commonOptions, indexAxis: 'y', plugins: { ...commonOptions.plugins, legend: { display: true }, tooltip: { callbacks: { label: (context) => `${context.dataset.label}: ${context.raw.toLocaleString('es-ES')} ${unit}` } } } });
    const comparisonDataset = { label: 'Anterior', barThickness: 15, borderRadius: 4, data: [] };
    const mainDataset = { label: 'Actual', barThickness: 15, borderRadius: 4, data: [] };
    
    const ventasFamiliaCanvas = document.getElementById('ventasFamiliaChart');
    if(ventasFamiliaCanvas) charts.ventasFamilia = new Chart(ventasFamiliaCanvas, { type: 'bar', data: { datasets: [{...mainDataset},{...comparisonDataset}] }, options: barChartOptions('uds.') });
    
    const ventasCategoriaCanvas = document.getElementById('ventasCategoriaChart');
    if(ventasCategoriaCanvas) charts.ventasCategoria = new Chart(ventasCategoriaCanvas, { type: 'bar', data: { datasets: [{...mainDataset},{...comparisonDataset}] }, options: barChartOptions('uds.') });
    
    const ventasUsuarioCanvas = document.getElementById('ventasUsuarioChart');
    if(ventasUsuarioCanvas) charts.ventasUsuario = new Chart(ventasUsuarioCanvas, { type: 'bar', data: { datasets: [{...mainDataset},{...comparisonDataset}] }, options: barChartOptions('tickets') });

    // Gráficos de Operaciones
    const opsTooltips = { ...commonOptions.plugins.tooltip, callbacks: { label: (context) => `${context.raw.toLocaleString('es-ES')} eventos` } };
    const opsQtyTooltips = { ...commonOptions.plugins.tooltip, callbacks: { label: (context) => `${context.raw.toLocaleString('es-ES')} uds.` } };
    
    const cancelacionesUsuarioCanvas = document.getElementById('cancelacionesUsuarioChart');
    if(cancelacionesUsuarioCanvas) charts.cancelacionesUsuario = new Chart(cancelacionesUsuarioCanvas, { type: 'bar', data: { datasets: [{label: 'Cancelaciones'}] }, options: { ...commonOptions, plugins: { ...commonOptions.plugins, legend: {display: false}, tooltip: opsTooltips }, x: { stacked: true }, y: { stacked: true } } });
    
    const mermasUsuarioCanvas = document.getElementById('mermasUsuarioChart');
    if(mermasUsuarioCanvas) charts.mermasUsuarioChart = new Chart(mermasUsuarioCanvas, { type: 'bar', data: { datasets: [{label: 'Mermas'}] }, options: { ...commonOptions, plugins: { ...commonOptions.plugins, legend: {display: false}, tooltip: opsQtyTooltips }, x: { stacked: true }, y: { stacked: true } } });

    const mermasMotivoCanvas = document.getElementById('mermasMotivoChart');
    if(mermasMotivoCanvas) {
        charts.mermasMotivo = new Chart(mermasMotivoCanvas, { 
            type: 'bar', 
            data: { datasets: [{ borderWidth: 1 }] }, 
            options: { ...commonOptions, indexAxis: 'y', scales: {x:{ticks:{display:false}}, y:{grid:{display:false}}}, plugins: { ...commonOptions.plugins, legend: { display: false }, tooltip: opsQtyTooltips },
                onClick: (evt, elements) => {
                    if (elements.length > 0) {
                        const i = elements[0].index;
                        const label = charts.mermasMotivo.data.labels[i];
                        applyMermaFilter(label);
                    }
                }
            } 
        });
    }

    // --- AÑADIDO: Creación de los nuevos gráficos para la página de Servicios ---
    const ventasPorZonaCanvas = document.getElementById('ventasPorZonaChart');
    if (ventasPorZonaCanvas) {
        charts.ventasPorZonaChart = new Chart(ventasPorZonaCanvas, {
            type: 'bar',
            data: { datasets: [{ label: 'Ventas (€)' }] },
            options: { ...barChartOptions('€'), plugins: { ...barChartOptions('€').plugins, legend: { display: false } } }
        });
    }

    const gastoComensalZonaCanvas = document.getElementById('gastoComensalZonaChart');
    if (gastoComensalZonaCanvas) {
        charts.gastoComensalZonaChart = new Chart(gastoComensalZonaCanvas, {
            type: 'bar',
            data: { datasets: [{ label: 'Gasto Medio (€)' }] },
            options: { ...barChartOptions('€'), plugins: { ...barChartOptions('€').plugins, legend: { display: false } } }
        });
    }
}

export function updateAllChartsTheme() {
    const isLight = !document.body.classList.contains('dark-theme');
    const palette = analysisChartPalettes[isLight ? 'light' : 'dark'];
    const textColor = getComputedStyle(document.documentElement).getPropertyValue('--text-secondary').trim();
    const borderColor = getComputedStyle(document.documentElement).getPropertyValue('--border-color').trim();
    const surfaceColor = getComputedStyle(document.documentElement).getPropertyValue('--surface-color').trim();
    const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--text-primary').trim();
    const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent-primary').trim();
    
    for (const chartKey in charts) {
        const chart = charts[chartKey];
        if (!chart) continue;
        const chartOptions = chart.options;
        
        if (chartOptions.plugins?.legend) chartOptions.plugins.legend.labels.color = textColor;
        if (chartOptions.plugins?.tooltip) {
            chartOptions.plugins.tooltip.backgroundColor = surfaceColor;
            chartOptions.plugins.tooltip.titleColor = primaryColor;
            chartOptions.plugins.tooltip.bodyColor = textColor;
            chartOptions.plugins.tooltip.borderColor = borderColor;
        }
        if (chartOptions.scales) {
            Object.values(chartOptions.scales).forEach(axis => {
                if (axis.ticks) axis.ticks.color = textColor;
                if (axis.grid) axis.grid.color = borderColor;
            });
        }
    }
    
    if (charts.ventasHora && charts.ventasHora.data.datasets.length > 0 && charts.ventasHora.data.datasets[0]) {
        if (!charts.ventasHora.data.datasets[1] || charts.ventasHora.data.datasets[1].data.length === 0) {
            charts.ventasHora.data.datasets[0].borderColor = accentColor;
            charts.ventasHora.data.datasets[0].backgroundColor = hexToRgba(accentColor, 0.15);
        }
    }
    
    if(charts.ventasMetodoPago && charts.ventasMetodoPago.data.datasets[0]) {
        charts.ventasMetodoPago.data.datasets[0].backgroundColor = Object.values(paymentMethodConfig).map(c => c.color);
    }
    
    if(charts.ventasFamilia) {
        charts.ventasFamilia.data.datasets[0].backgroundColor = palette[0];
        if(charts.ventasFamilia.data.datasets[1]) charts.ventasFamilia.data.datasets[1].backgroundColor = hexToRgba(palette[0], 0.35);
    }
    if(charts.ventasCategoria) {
        charts.ventasCategoria.data.datasets[0].backgroundColor = palette[1];
        if(charts.ventasCategoria.data.datasets[1]) charts.ventasCategoria.data.datasets[1].backgroundColor = hexToRgba(palette[1], 0.35);
    }
    if(charts.ventasUsuario) {
        charts.ventasUsuario.data.datasets[0].backgroundColor = palette[2];
        if(charts.ventasUsuario.data.datasets[1]) charts.ventasUsuario.data.datasets[1].backgroundColor = hexToRgba(palette[2], 0.35);
    }
    if(charts.cancelacionesUsuario) {
        charts.cancelacionesUsuario.data.datasets[0].backgroundColor = palette[3];
    }
    if(charts.mermasUsuarioChart) {
        charts.mermasUsuarioChart.data.datasets[0].backgroundColor = palette[4];
    }
    if(charts.mermasMotivo) {
        charts.mermasMotivo.data.datasets[0].backgroundColor = palette;
    }

    // --- AÑADIDO: Aplicar colores a los nuevos gráficos de Servicios ---
    if(charts.ventasPorZonaChart) {
        charts.ventasPorZonaChart.data.datasets[0].backgroundColor = palette[5] || palette[0];
    }
    if(charts.gastoComensalZonaChart) {
        charts.gastoComensalZonaChart.data.datasets[0].backgroundColor = palette[6] || palette[1];
    }
    
    for (const chartKey in charts) { 
        if(charts[chartKey]) charts[chartKey].update('none'); 
    }
}