import { charts, updateAllChartsTheme } from './charts.js';
import { getComparisonHtml } from './utils.js';

/**
 * Parsea el texto del campo "Preview" para extraer datos estructurados.
 * Usa expresiones regulares para encontrar y extraer la información clave.
 */
function parsePreviewData(previewText) {
    const extracted = {
        comensalesPorZona: [],
        ventasPorZona: [],
        totalComensales: 0,
    };

    if (!previewText) return extracted;

    // Extraer bloque de COMENSALES POR CENTRO DE VENTA
    const comensalesBlockMatch = previewText.match(/COMENSALES POR CENTRO DE VENTA\s*([\s\S]*?)\s*={10,}/);
    if (comensalesBlockMatch && comensalesBlockMatch[1]) {
        // Expresión regular para cada fila: Nombre (texto), Comensales (número), Media (número con coma), Gasto (número con coma)
        const comensalesRows = comensalesBlockMatch[1].matchAll(/^(.+?)\s+(\d+)\s+([\d,]+)\s+([\d,]+)\s€/gm);
        for (const match of comensalesRows) {
            const zona = match[1].trim();
            const comensales = parseInt(match[2], 10);
            const gastoPorComensal = parseFloat(match[4].replace(',', '.'));
            extracted.comensalesPorZona.push({ zona, comensales, gastoPorComensal });
            extracted.totalComensales += comensales;
        }
    }

    // Extraer bloque de VENTAS POR CENTRO DE VENTA
    const ventasBlockMatch = previewText.match(/VENTAS POR CENTRO DE VENTA\s*([\s\S]*?)\s*={10,}/);
    if (ventasBlockMatch && ventasBlockMatch[1]) {
        // Expresión regular para cada fila: Nombre (texto), Ops (número), Total (número con puntos y coma)
        const ventasRows = ventasBlockMatch[1].matchAll(/^(.+?)\s+\d+\s+([\d.,]+)\s€/gm);
        for (const match of ventasRows) {
            const zona = match[1].trim();
            const total = parseFloat(match[2].replace(/\./g, '').replace(',', '.'));
            extracted.ventasPorZona.push({ zona, total });
        }
    }
    
    return extracted;
}

export function updateServiciosPage(mainData, comparisonData) {
    const placeholder = document.getElementById('servicios-placeholder');
    const content = document.getElementById('servicios-content');
    const kpiContainer = document.getElementById('kpi-servicios-container');

    if (!mainData || mainData.length === 0) {
        placeholder.style.display = 'block';
        content.style.display = 'none';
        return;
    }
    placeholder.style.display = 'none';
    content.style.display = 'block';

    let totalDuration = 0;
    let serviceCount = 0;
    let totalComensales = 0;
    const ventasPorZona = {};
    const gastoPorComensalZona = {};
    
    mainData.forEach(periodo => {
        const open = new Date(periodo.OpenDate);
        const close = new Date(periodo.CloseDate);
        if (close > open) {
            totalDuration += (close - open);
            serviceCount++;
        }

        const parsedData = parsePreviewData(periodo.Preview);
        totalComensales += parsedData.totalComensales;

        parsedData.ventasPorZona.forEach(({ zona, total }) => {
            ventasPorZona[zona] = (ventasPorZona[zona] || 0) + total;
        });
        
        parsedData.comensalesPorZona.forEach(({ zona, gastoPorComensal, comensales }) => {
            if (!gastoPorComensalZona[zona]) {
                gastoPorComensalZona[zona] = { totalGasto: 0, totalComensales: 0 };
            }
            gastoPorComensalZona[zona].totalGasto += gastoPorComensal * comensales;
            gastoPorComensalZona[zona].totalComensales += comensales;
        });
    });

    const avgDurationMinutes = serviceCount > 0 ? (totalDuration / serviceCount / 1000 / 60) : 0;
    const hours = Math.floor(avgDurationMinutes / 60);
    const minutes = Math.round(avgDurationMinutes % 60);
    const avgServiceTime = `${hours}h ${minutes}m`;
    const avgComensales = serviceCount > 0 ? totalComensales / serviceCount : 0;
    
    kpiContainer.innerHTML = `
        <div class="content-block kpi-metric"><div class="title">Tiempo Promedio Servicio</div><div class="value">${avgServiceTime}</div></div>
        <div class="content-block kpi-metric"><div class="title">Total Comensales</div><div class="value">${totalComensales.toLocaleString('es-ES')}</div></div>
        <div class="content-block kpi-metric"><div class="title">Comensales / Servicio</div><div class="value">${avgComensales.toFixed(1)}</div></div>
        <div class="content-block kpi-metric"><div class="title">Nº de Servicios</div><div class="value">${serviceCount}</div></div>
    `;

    const sortedVentasZona = Object.entries(ventasPorZona).sort(([,a],[,b]) => b - a);
    charts.ventasPorZonaChart.data.labels = sortedVentasZona.map(item => item[0]);
    charts.ventasPorZonaChart.data.datasets[0].data = sortedVentasZona.map(item => item[1]);
    
    const avgGastoZona = {};
    for(const zona in gastoPorComensalZona){
        const data = gastoPorComensalZona[zona];
        avgGastoZona[zona] = data.totalComensales > 0 ? data.totalGasto / data.totalComensales : 0;
    }
    const sortedGastoZona = Object.entries(avgGastoZona).sort(([,a],[,b]) => b - a);
    charts.gastoComensalZonaChart.data.labels = sortedGastoZona.map(item => item[0]);
    charts.gastoComensalZonaChart.data.datasets[0].data = sortedGastoZona.map(item => item[1]);
    
    updateAllChartsTheme();
}