export const config = {
    apiUrl: 'http://161.22.41.105:8984/api/custom-query/',
    apiToken: 'Parkingpizzaserver2023$'
};

export const paymentMethodConfig = {
    'Tarjeta':  { color: '#80deea', dataKey: 'Tarjeta' },
    'Efectivo': { color: '#a5d6a7', dataKey: 'Efectivo ' },
    'GLOVO':    { color: '#ffcc80', dataKey: 'GLOVO' },
    'Otros':    { color: '#b39ddb', dataKey: 'Otros' }
};

export const analysisChartPalettes = {
    dark: ['#80deea', '#a5d6a7', '#ffcc80', '#ffab91', '#b39ddb', '#f48fb1', '#80cbc4', '#c5e1a5', '#ffe082', '#ffccbc'],
    light: ['#4dd0e1', '#81c784', '#ffb74d', '#ff8a65', '#9575cd', '#f06292', '#4db6ac', '#aed581', '#ffd54f', '#ffab91']
};