import { createAllCharts } from './charts.js';
import { setupNavigation, setupThemeSwitcher, setupControls } from './ui.js';
import { fetchDualPeriodData } from './api.js';
import { getComparisonDates } from './utils.js';
import { updateResumenPage, setupResumenInteractivity } from './page_resumen.js';
import { updateVentasPage } from './page_ventas.js';
import { updateOperacionesPage } from './page_operaciones.js';
import { updateServiciosPage } from './page_servicios.js'; // <-- AÑADIDO

document.addEventListener('DOMContentLoaded', () => {
    const state = {
        resumen: {},
        ventas: {},
        operaciones: {},
        servicios: {} // <-- AÑADIDO
    };

    createAllCharts(state);
    setupThemeSwitcher();
    setupNavigation(state, (forceReload, currentState) => loadDataForVisibleSection(forceReload, currentState));
    setupControls(() => loadDataForVisibleSection(true, state));
    
    const clearCacheBtn = document.getElementById('clearCacheBtn');
    if (clearCacheBtn) {
        clearCacheBtn.addEventListener('click', () => {
            localforage.clear().then(() => {
                alert('Caché limpiada. Los datos se recargarán desde la fuente original.');
                loadDataForVisibleSection(true, state);
            });
        });
    }
    
    loadDataForVisibleSection(true, state);

    async function loadDataForVisibleSection(forceReload = true, currentState) {
        const activeLink = document.querySelector('.nav-menu a.active');
        if (!activeLink) return;
        
        const targetId = activeLink.getAttribute('href').substring(1);
        const refreshButton = document.getElementById('refreshDataBtn');
        
        refreshButton.innerHTML = '<i class="bi bi-arrow-clockwise spinning"></i>';
        refreshButton.disabled = true;

        const mainDates = { from: document.getElementById('dateFrom').value, to: document.getElementById('dateTo').value };
        const comparisonDates = getComparisonDates(mainDates.from, mainDates.to, document.getElementById('comparisonSelector').value);
        
        try {
            if (targetId === 'resumen') {
                if (forceReload || !currentState.resumen.main) {
                     const [mainData, comparisonData] = await fetchDualPeriodData('{informe-metodos-pago-dashboard}', mainDates, comparisonDates);
                     currentState.resumen = { main: mainData, comparison: comparisonData };
                }
                updateResumenPage(currentState.resumen.main, currentState.resumen.comparison, currentState);
                setupResumenInteractivity(currentState); 
            } else if (targetId === 'ventas') {
                if (forceReload || !currentState.ventas.main) {
                    const [mainData, comparisonData] = await fetchDualPeriodData('{informe-analisis-ventas}', mainDates, comparisonDates);
                    currentState.ventas = { main: mainData, comparison: comparisonData };
                }
                updateVentasPage(currentState.ventas.main, currentState.ventas.comparison);
            } else if (targetId === 'operaciones') {
                if (forceReload || !currentState.operaciones.main) {
                    const [[mainCancel, comparisonCancel], [mainMerma, comparisonMerma]] = await Promise.all([
                        fetchDualPeriodData('{cancelaciones-dashboard}', mainDates, comparisonDates),
                        fetchDualPeriodData('{mermas-dashboard}', mainDates, comparisonDates)
                    ]);
                    
                    currentState.operaciones = {
                        main: { cancelaciones: mainCancel, mermas: mainMerma },
                        comparison: { cancelaciones: comparisonCancel, mermas: comparisonMerma }
                    };
                }
                updateOperacionesPage(currentState.operaciones.main, currentState.operaciones.comparison);
            } else if (targetId === 'servicios') { // <-- AÑADIDO
                if (forceReload || !currentState.servicios.main) {
                    const [mainData, comparisonData] = await fetchDualPeriodData('{periodos-servicio-dashboard}', mainDates, comparisonDates);
                    currentState.servicios = { main: mainData, comparison: comparisonData };
                }
                updateServiciosPage(currentState.servicios.main, currentState.servicios.comparison);
            }
        } catch (error) {
            console.error("Error al actualizar la página:", error);
        }
        finally {
            refreshButton.innerHTML = '<i class="bi bi-arrow-clockwise"></i>';
            refreshButton.disabled = false;
        }
    }
});