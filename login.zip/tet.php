<?php


// Definir los parámetros de la consulta en formato JSON
$query_params = array(
    "QueryGuid" => "{periodos-servicio-dashboard}",
    "Params" => array(
        "from" => "2025-06-13",
        "to" => "2025-07-13",
    )
);


// Convertir el array en formato JSON
$query_json = json_encode($query_params);


// URL a la que se realizará la petición POST
$url = 'http://161.22.41.105:8984/api/custom-query/';


// Cabeceras requeridas para la petición POST
$headers = array(
    'Api-Token: Parkingpizzaserver2023$',
    'Accept: application/json',
    'Content-Type: application/json; charset=utf-8'
);


// Inicializar cURL para realizar la petición POST
$ch = curl_init($url);


// Establecer opciones para la petición cURL
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $query_json);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);


// Ejecutar la petición cURL y obtener la respuesta
$response = curl_exec($ch);


// Comprobar si hay errores en la petición
if($response === false) {
    $error = curl_error($ch);
    echo "Error en la petición cURL: " . $error;
} else {
    // Decodificar la respuesta JSON
    $result = json_decode($response, true);
    // Manejar la respuesta según sea necesario
    print_r($result);
}


// Cerrar la sesión cURL
curl_close($ch);


?>
